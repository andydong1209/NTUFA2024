﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
using System.IO;

namespace DHestonModel
{
    public class HestonPrice
    {
        // Heston Integrand
        public double HestonProb(double phi, HParam param, OpSet settings, int Pnum)
        {
            Complex i = new Complex(0.0, 1.0);   // Imaginary unit
            double S = settings.S;
            double K = settings.K;
            double T = settings.T;
            double r = settings.r;
            double q = settings.q;
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = param.lambda;
            double x = Math.Log(S);
            double a = kappa * theta;
            int Trap = settings.trap;
            Complex b, u, d, g, c, D, G, C, f, integrand = new Complex();

            // Parameters "u" and "b" are different for P1 and P2
            if (Pnum == 1)
            {
                u = 0.5;
                b = kappa + lambda - rho * sigma;
            }
            else
            {
                u = -0.5;
                b = kappa + lambda;
            }

            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2.0) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Math.Log(K)) * f / i / phi;

            // Return the real part of the integrand.
            return integrand.Real;
        }


        // Heston Price by Gauss-Laguerre Integration
        public double HestonPriceGaussLaguerre(HParam param, OpSet settings, double[] x, 
            double[] w)
        {
            double[] int1 = new Double[32];
            double[] int2 = new Double[32];
            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                int1[j] = w[j] * HestonProb(x[j], param, settings, 1);
                int2[j] = w[j] * HestonProb(x[j], param, settings, 2);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum();
            double P2 = 0.5 + 1.0 / pi * int2.Sum();

            // The call price
            double S = settings.S;
            double K = settings.K;
            double T = settings.T;
            double r = settings.r;
            double q = settings.q;
            string PutCall = settings.PutCall;
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }


        // Heston Integrand
        public double HestonProb(double phi, HParam param, double S, double K, double r, 
            double q, double T, int Pnum, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);      // Imaginary unit
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = 0.0;
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C, f, integrand = new Complex();

            // Parameters "u" and "b" are different for P1 and P2
            if (Pnum == 1)
            {
                u = 0.5;
                b = kappa + lambda - rho * sigma;
            }
            else
            {
                u = -0.5;
                b = kappa + lambda;
            }
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Complex.Log(K)) * f / i / phi;

            // Return the real part of the integrand.
            return integrand.Real;
        }

        // Heston Price by Gauss-Laguerre Integration ========================================
        public double HestonPriceGaussLaguerre(HParam param, double S, double K, double r, 
            double q, double T, int trap, string PutCall, double[] x, double[] w)
        {
            double[] int1 = new Double[32];
            double[] int2 = new Double[32];

            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                int1[j] = w[j] * HestonProb(x[j], param, S, K, r, q, T, 1, trap);
                int2[j] = w[j] * HestonProb(x[j], param, S, K, r, q, T, 2, trap);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum();
            double P2 = 0.5 + 1.0 / pi * int2.Sum();

            // The call price
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }


        // Heston Integrand
        public double HestonProb(double phi, double kappa, double theta, double lambda, 
            double rho, double sigma, double T, double K, double S, double r, double q, 
            double v0, int Pnum, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C, f, integrand = new Complex();

            // Parameters "u" and "b" are different for P1 and P2
            if (Pnum == 1)
            {
                u = 0.5;
                b = kappa + lambda - rho * sigma;
            }
            else
            {
                u = -0.5;
                b = kappa + lambda;
            }
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Complex.Log(K)) * f / i / phi;

            // Return the real part of the integrand.
            return integrand.Real;
        }

        // Heston Price by Gauss-Laguerre Integration
        public double HestonPriceGaussLaguerre(string PutCall, double S, double K, double r,
            double q, double T, double kappa, double theta, double sigma, double v0, 
            double lambda, double rho, double[] x, double[] w, int trap)
        {
            double[] int1 = new Double[32];
            double[] int2 = new Double[32];
            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                int1[j] = w[j] * HestonProb(x[j], kappa, theta, lambda, rho, sigma, T, K, 
                    S, r, q, v0, 1, trap);
                int2[j] = w[j] * HestonProb(x[j], kappa, theta, lambda, rho, sigma, T, K, 
                    S, r, q, v0, 2, trap);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum();
            double P2 = 0.5 + 1.0 / pi * int2.Sum();

            // The call price
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }

        // Attari Integrand
        public double AttariProb(double phi, double kappa, double theta, double lambda, 
            double rho, double sigma, double T, double K, double S, double r, double q, 
            double v0, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            Complex b, u, d, g, c, D, G, C, f = new Complex();

            double x = Math.Log(S);
            double a = kappa * theta;

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2.0) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The Attari characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * r * T);

            // The Attari (2004) integrand
            Complex L = Complex.Log(Complex.Exp(-r * T) * K / S);
            Complex y = ((f.Real + f.Imaginary / phi) * Complex.Cos(L * phi) 
                + (f.Imaginary - f.Real / phi) * Complex.Sin(L * phi)) / (1 + phi * phi);
            return y.Real;
        }

        // The Attari call price using Gauss-Laguerre 32 point integration+
        public double AttariPriceGaussLaguerre(string PutCall, double S, double K, double T,
            double r, double q, double kappa, double theta, double sigma, double lambda, 
            double v0, double rho, int trap, double[] x, double[] w)
        {
            double[] int1 = new Double[32];
            for (int k = 0; k <= 31; k++)
                int1[k] = w[k] * AttariProb(x[k], kappa, theta, lambda, rho, sigma, T, K, S,
                    r, q, v0, trap);

            // The call price
            double pi = Math.PI;
            double HestonC = S * Math.Exp(-q * T) - K * Math.Exp(-r * T) 
                * (0.5 + 1.0 / pi * int1.Sum());

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }

        // Heston Characteristic Function (f2)
        public Complex HestonCF(Complex phi, double kappa, double theta, double lambda, 
            double rho, double sigma, double T, double K, double S, double r, double q, 
            double v0, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            Complex b, u, d, g, c, D, G, C = new Complex();
            double x = Math.Log(S);
            double a = kappa * theta;

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x);
        }

        // Heston Price by Gauss-Laguerre Integration
        public double HestonPriceGaussLaguerre(string Integrand, string PutCall, double alpha,
            double S, double K, double r, double q, double T, double kappa, double theta, 
            double sigma, double v0, double lambda, double rho, double[] x, double[] w, int trap)
        {
            if (Integrand == "Heston")
            {
                double[] int1 = new Double[32];
                double[] int2 = new Double[32];

                // Numerical integration
                for (int k = 0; k <= 31; k++)
                {
                    int1[k] = w[k] * HestonProb(x[k], kappa, theta, lambda, rho, sigma, T, K, 
                        S, r, q, v0, 1, trap);
                    int2[k] = w[k] * HestonProb(x[k], kappa, theta, lambda, rho, sigma, T, K, 
                        S, r, q, v0, 2, trap);
                }

                // Define P1 and P2
                double pi = Math.PI;
                double P1 = 0.5 + 1.0 / pi * int1.Sum();
                double P2 = 0.5 + 1.0 / pi * int2.Sum();

                // The call price
                double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

                // The put price by put-call parity
                double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

                // Output the option price
                if (PutCall == "C")
                    return HestonC;
                else
                    return HestonP;
            }
            else
            {
                double[] int1 = new Double[32];
                for (int k = 0; k <= 31; k++)
                    int1[k] = w[k] * CarrMadanIntegrand(x[k], alpha, kappa, theta, lambda, rho,
                        sigma, T, K, S, r, q, v0, trap, PutCall);

                // The Option Price
                double pi = Math.PI;
                if (PutCall == "C")
                    return Math.Exp(-alpha * Math.Log(K)) * int1.Sum() / pi;
                else
                    return Math.Exp(alpha * Math.Log(K)) * int1.Sum() / pi;

                //return int1.Sum();
            }
        }

        // Returns the Carr-Madan integrand,
        // based on the Heston characteristic function, f2 (the second CF)
        public double CarrMadanIntegrand(double u, double alpha, double kappa, double theta,
            double lambda, double rho, double sigma, double T, double K, double S, double r,
            double q, double v0, int trap, string PutCall)
        {
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            Complex one = new Complex(1.0, 0.0);
            Complex two = new Complex(2.0, 0.0);
            Complex integrand;
            if (PutCall == "C")
                integrand = Complex.Exp(-i * u * Complex.Log(K)) * Complex.Exp(-r * T)
                    * HestonCF(u - (alpha + one) * i, kappa, theta, lambda, rho, sigma, T, K, S, r, q, v0, trap)
                    / (alpha * alpha + alpha - u * u + i * (two * alpha + one) * u);
            else
                integrand = Complex.Exp(-i * u * Complex.Log(K)) * Complex.Exp(-r * T)
                    * HestonCF(u - (-alpha + one) * i, kappa, theta, lambda, rho, sigma, T, K, S, r, q, v0, trap)
                    / (alpha * alpha - alpha - u * u + i * (-two * alpha + one) * u);
            return integrand.Real;
        }


        // Heston Integrand
        public double HestonProb(double phi, double kappa, double theta, double lambda, 
            double rho, double sigma, double T, double K, double S, double r, double v0, 
            int Pnum, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C, f, integrand = new Complex();

            // Parameters "u" and "b" are different for P1 and P2
            if (Pnum == 1)
            {
                u = 0.5;
                b = kappa + lambda - rho * sigma;
            }
            else
            {
                u = -0.5;
                b = kappa + lambda;
            }
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2.0) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1.0 - c);
                C = r * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = r * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Complex.Log(K)) * f / i / phi;

            // The real part of the integrand
            return integrand.Real;
        }

        // Heston Characteristic Function (f2)
        public Complex HestonCF(Complex phi, double kappa, double theta, double lambda,
            double rho, double sigma, double T, double K, double S, double r, double v0,
            int Trap)
        {
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C = new Complex(); //f

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2.0) 
                - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1.0 - c);
                C = r * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = r * i * phi * T + a / sigma / sigma 
                    * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x);
        }



        // Heston Price by Gauss-Laguerre Integration
        public double HestonPriceGaussLaguerre(string Integrand, string PutCall, double S, 
            double K, double r, double T, double kappa, double theta, double sigma, double v0,
            double lambda, double rho, double[] x, double[] w, int trap, double alpha)
        {
            double pi = Math.PI;
            if (Integrand == "Heston")
            {
                double[] int1 = new Double[32];
                double[] int2 = new Double[32];

                // Numerical integration
                for (int k = 0; k <= 31; k++)
                {
                    int1[k] = w[k] * HestonProb(x[k], kappa, theta, lambda, rho, sigma, T, K, 
                        S, r, v0, 1, trap);
                    int2[k] = w[k] * HestonProb(x[k], kappa, theta, lambda, rho, sigma, T, K,
                        S, r, v0, 2, trap);
                }

                // Define P1 and P2
                double P1 = 0.5 + 1.0 / pi * int1.Sum();
                double P2 = 0.5 + 1.0 / pi * int2.Sum();

                // The call price
                double HestonC = S * P1 - K * Math.Exp(-r * T) * P2;

                // The put price by put-call parity
                double HestonP = HestonC - S + K * Math.Exp(-r * T);

                // Output the option price
                if (PutCall == "C")
                    return HestonC;
                else
                    return HestonP;
            }
            else if (Integrand == "CarrMadan")
            {
                double[] int1 = new Double[32];
                for (int k = 0; k <= 31; k++)
                {
                    int1[k] = w[k] * CarrMadanIntegrandOTM(x[k], kappa, theta, lambda, rho, 
                        sigma, T, K, S, r, v0, trap);
                }

                return int1.Sum() / pi;
            }
            else if (Integrand == "CarrMadanDamped")
            {
                double[] int1 = new Double[32];
                for (int k = 0; k <= 31; k++)
                {
                    int1[k] = w[k] * CarrMadanDampedIntegrandOTM(x[k], kappa, theta, lambda,
                        rho, sigma, T, K, S, r, v0, trap, alpha);
                }

                return 1.0 / Math.Sinh(alpha * Math.Log(K)) * int1.Sum() / pi;
            }
            else return 0.0;
        }

        // Returns the undamped Carr-Madan integrand for OTM options
        public double CarrMadanIntegrandOTM(double u, double kappa, double theta, 
            double lambda, double rho, double sigma, double T, double K, double S,
            double r, double v0, int trap)
        {
            Complex i = new Complex(0.0, 1.0);
            Complex phi = HestonCF(u - i, kappa, theta, lambda, rho, sigma, T, K, S, r, v0, trap);
            Complex integrand = Complex.Exp(-i * u * Math.Log(K)) * Math.Exp(-r * T)
                * (Complex.Pow(S, (i * u + 1.0)) / (1.0 + i * u) - Math.Exp(r * T) 
                * Complex.Pow(S, (i * u + 1.0)) / (i * u) - phi / (u * u - i * u));
            return integrand.Real;
        }
        // Returns the damped Carr-Madan integrand for OTM options
        public double CarrMadanDampedIntegrandOTM(double v, double kappa, double theta, 
            double lambda, double rho, double sigma, double T, double K, double S, double r,
            double v0, int Trap, double alpha)
        {
            // Calculate z(v-ia)
            Complex i = new Complex(0.0, 1.0);
            Complex u = v - i * alpha;
            Complex phi = HestonCF(u - i, kappa, theta, lambda, rho, sigma, T, K, S, r, v0, Trap);
            Complex z1 = Math.Exp(-r * T) * (Complex.Pow(S, (i * u + 1.0)) / (1.0 + i * u) 
                - Math.Exp(r * T) * Complex.Pow(S, (i * u + 1.0)) / (i * u) - phi / (u * u - i * u));

            // Calculate z(v+ia)
            u = v + i * alpha;
            phi = HestonCF(u - i, kappa, theta, lambda, rho, sigma, T, K, S, r, v0, Trap);
            Complex z2 = Math.Exp(-r * T) * (Complex.Pow(S, (i * u + 1.0)) / (1.0 + i * u) 
                - Math.Exp(r * T) * Complex.Pow(S, (i * u + 1.0)) / (i * u) - phi / (u * u - i * u));

            // Calculate the Fourier transform of y 
            Complex y = Complex.Exp(-i * u * Math.Log(K)) * (z1 - z2) / 2.0;

            // Return the real part only
            return y.Real;
        }

        // Heston characteristic function (f2)
        public Complex HestonCF(Complex phi, HParam param, OpSet settings)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double S = settings.S;
            double K = settings.K;
            double T = settings.T;
            double r = settings.r;
            double q = settings.q;
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = param.lambda;
            double x = Math.Log(S);
            double a = kappa * theta;
            int Trap = settings.trap;
            Complex b, u, d, g, c, D, G, C = new Complex();

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x);
        }


        // Heston Price by Gauss-Legendre Integration
        public double HestonPriceGaussLegendre(HParam param, OpSet settings, double[] x, double[] w, double a, double b)
        {
            double[] int1 = new Double[32];
            double[] int2 = new Double[32];
            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                double X = (a + b) / 2.0 + (b - a) / 2.0 * x[j];
                int1[j] = w[j] * HestonProb(X, param, settings, 1);
                int2[j] = w[j] * HestonProb(X, param, settings, 2);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum() * (b - a) / 2.0;
            double P2 = 0.5 + 1.0 / pi * int2.Sum() * (b - a) / 2.0;

            // The call price
            double S = settings.S;
            double K = settings.K;
            double T = settings.T;
            double r = settings.r;
            double q = settings.q;
            string PutCall = settings.PutCall;
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }

        // Heston characteristic function (f2) ==============================================================================
        public Complex HestonCF(Complex phi, HParam param, double S, double r, double q, double T, int trap)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = param.lambda;
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C = new Complex(); //f

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x);
        }


        // Attari Characteristic Function ==================================================================================================
        public Complex AttariCF(double phi, HParam param, double Tau, double Spot, double Rate, double Div, int Trap)
        {
            Complex S = new Complex(Spot, 0.0);	    // Spot Price
            Complex T = new Complex(Tau, 0.0);       // Maturity in years
            Complex r = new Complex(Rate, 0.0);       // Interest rate
            Complex q = new Complex(Div, 0.0);       // Dividend yield
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            Complex rho = new Complex(param.rho, 0.0);       // Heston parameter: correlation
            Complex kappa = new Complex(param.kappa, 0.0);       // Heston parameter: mean reversion speed
            Complex theta = new Complex(param.theta, 0.0);       // Heston parameter: mean reversion speed
            Complex lambda = new Complex(param.lambda, 0.0);       // Heston parameter: price of volatility risk
            Complex sigma = new Complex(param.sigma, 0.0);       // Heston parameter: volatility of variance
            Complex v0 = new Complex(param.v0, 0.0);        // Heston parameter: initial variance
            Complex x = Complex.Log(S);
            Complex a = kappa * theta;
            Complex b, u, d, g, c, D, G, C = new Complex();

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The Attari characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x) * Complex.Exp(-i * phi * (x + r * T));
        }


        // Heston Integrand
        public double HestonProb(double phi, DiffEvoAlgo.HParam param, double S, double K, double r, double q, double T, int Pnum, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = 0.0;
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C, f, integrand = new Complex();

            // Parameters "u" and "b" are different for P1 and P2
            if (Pnum == 1)
            {
                u = 0.5;
                b = kappa + lambda - rho * sigma;
            }
            else
            {
                u = -0.5;
                b = kappa + lambda;
            }
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Complex.Log(K)) * f / i / phi;

            // Return the real part of the integrand.
            return integrand.Real;
        }

        // Heston Price by Gauss-Laguerre Integration =================================================================
        public double HestonPriceGaussLaguerre(DiffEvoAlgo.HParam param, double S, double K, double r, double q, double T, int trap, string PutCall, double[] x, double[] w)
        {
            double[] int1 = new Double[32];
            double[] int2 = new Double[32];

            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                int1[j] = w[j] * HestonProb(x[j], param, S, K, r, q, T, 1, trap);
                int2[j] = w[j] * HestonProb(x[j], param, S, K, r, q, T, 2, trap);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum();
            double P2 = 0.5 + 1.0 / pi * int2.Sum();

            // The call price
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }


        // Heston Integrand
        public double HestonProb(double phi, SP500.HParam param, double S, double K, double r, double q, double T, int Pnum, int Trap)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = 0.0;
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C, f, integrand = new Complex();

            // Parameters "u" and "b" are different for P1 and P2
            if (Pnum == 1)
            {
                u = 0.5;
                b = kappa + lambda - rho * sigma;
            }
            else
            {
                u = -0.5;
                b = kappa + lambda;
            }
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            f = Complex.Exp(C + D * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Complex.Log(K)) * f / i / phi;

            // Return the real part of the integrand.
            return integrand.Real;
        }

        // Heston Price by Gauss-Laguerre Integration =================================================================
        public double HestonPriceGaussLaguerre(SP500.HParam param, double S, double K, double r, double q, double T, int trap, string PutCall, double[] x, double[] w)
        {
            double[] int1 = new Double[32];
            double[] int2 = new Double[32];

            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                int1[j] = w[j] * HestonProb(x[j], param, S, K, r, q, T, 1, trap);
                int2[j] = w[j] * HestonProb(x[j], param, S, K, r, q, T, 2, trap);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum();
            double P2 = 0.5 + 1.0 / pi * int2.Sum();

            // The call price
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }


        // Heston characteristic function (f2) ==============================================================================
        public Complex HestonCF(Complex phi, SP500SVC.HParam param, double S, double r, double q, double T, int trap)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = param.lambda;
            double x = Math.Log(S);
            double a = kappa * theta;
            Complex b, u, d, g, c, D, G, C = new Complex();

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x);
        }

        // Attari Characteristic Function ==================================================================================================
        public Complex AttariCF(double phi, SP500SVC.HParam param, double Tau, double Spot, double Rate, double Div, int Trap)
        {
            Complex S = new Complex(Spot, 0.0);	    // Spot Price
            Complex T = new Complex(Tau, 0.0);       // Maturity in years
            Complex r = new Complex(Rate, 0.0);       // Interest rate
            Complex q = new Complex(Div, 0.0);       // Dividend yield
            Complex i = new Complex(0.0, 1.0);       // Imaginary unit
            Complex rho = new Complex(param.rho, 0.0);       // Heston parameter: correlation
            Complex kappa = new Complex(param.kappa, 0.0);       // Heston parameter: mean reversion speed
            Complex theta = new Complex(param.theta, 0.0);       // Heston parameter: mean reversion speed
            Complex lambda = new Complex(param.lambda, 0.0);       // Heston parameter: price of volatility risk
            Complex sigma = new Complex(param.sigma, 0.0);       // Heston parameter: volatility of variance
            Complex v0 = new Complex(param.v0, 0.0);        // Heston parameter: initial variance
            Complex x = Complex.Log(S);
            Complex a = kappa * theta;
            Complex b, u, d, g, c, D, G, C = new Complex();

            u = -0.5;
            b = kappa + lambda;
            d = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b, 2) - sigma * sigma * (2.0 * u * i * phi - phi * phi));
            g = (b - rho * sigma * i * phi + d) / (b - rho * sigma * i * phi - d);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c = 1.0 / g;
                D = (b - rho * sigma * i * phi - d) / sigma / sigma * ((1.0 - Complex.Exp(-d * T)) / (1.0 - c * Complex.Exp(-d * T)));
                G = (1.0 - c * Complex.Exp(-d * T)) / (1 - c);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi - d) * T - 2.0 * Complex.Log(G));
            }
            else
            {
                // Original Heston formulation.
                G = (1.0 - g * Complex.Exp(d * T)) / (1.0 - g);
                C = (r - q) * i * phi * T + a / sigma / sigma * ((b - rho * sigma * i * phi + d) * T - 2.0 * Complex.Log(G));
                D = (b - rho * sigma * i * phi + d) / sigma / sigma * ((1.0 - Complex.Exp(d * T)) / (1.0 - g * Complex.Exp(d * T)));
            }

            // The Attari characteristic function.
            return Complex.Exp(C + D * v0 + i * phi * x) * Complex.Exp(-i * phi * (x + r * T));
        }

        // Heston Price by Gauss-Laguerre Integration =============================================================================================================
        public double HestonPriceGaussLaguerre(SP500SVC.HParam param, double S, double K, double r, double q, double T, int trap, string PutCall, double[] X, double[] W)
        {
            Complex i = new Complex(0.0, 1.0);
            Complex[] f1 = new Complex[32];
            Complex[] f2 = new Complex[32];
            double[] int1 = new double[32];
            double[] int2 = new double[32];

            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                double phi = X[j];
                f1[j] = HestonCF(phi - i, param, S, r, q, T, trap) / (S * Math.Exp((r - q) * T));
                f2[j] = HestonCF(phi, param, S, r, q, T, trap);
                Complex FF1 = Complex.Exp(-i * phi * Complex.Log(K)) * f1[j] / i / phi;
                Complex FF2 = Complex.Exp(-i * phi * Complex.Log(K)) * f2[j] / i / phi;
                int1[j] = W[j] * FF1.Real;
                int2[j] = W[j] * FF2.Real;
            }

            // Define P1 and P2
            double pi = Math.PI;
            double P1 = 0.5 + 1.0 / pi * int1.Sum();
            double P2 = 0.5 + 1.0 / pi * int2.Sum();

            // The call price
            double HestonC = S * Math.Exp(-q * T) * P1 - K * Math.Exp(-r * T) * P2;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }
    }


    public class HestonPriceConsolidated
    {
        // Heston Integrand
        public double HestonProbConsol(double phi, HParam param, OpSet settings)
        {
            Complex i = new Complex(0.0, 1.0);                   // Imaginary unit
            double S = settings.S;
            double K = settings.K;
            double T = settings.T;
            double r = settings.r;
            double q = settings.q;
            double kappa = param.kappa;
            double theta = param.theta;
            double sigma = param.sigma;
            double v0 = param.v0;
            double rho = param.rho;
            double lambda = param.lambda;
            double x = Math.Log(S);
            double a = kappa * theta;
            int Trap = settings.trap;
            Complex b1, u1, d1, g1, c1, D1, G1, C1, f1,
                    b2, u2, d2, g2, c2, D2, G2, C2, f2, integrand = new Complex();

            // The first characteristic function
            u1 = 0.5;
            b1 = kappa + lambda - rho * sigma;
            d1 = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b1, 2) 
                - sigma * sigma * (2.0 * u1 * i * phi - phi * phi));
            g1 = (b1 - rho * sigma * i * phi + d1) / (b1 - rho * sigma * i * phi - d1);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c1 = 1.0 / g1;
                D1 = (b1 - rho * sigma * i * phi - d1) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d1 * T)) / (1.0 - c1 * Complex.Exp(-d1 * T)));
                G1 = (1.0 - c1 * Complex.Exp(-d1 * T)) / (1.0 - c1);
                C1 = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b1 - rho * sigma * i * phi - d1) * T - 2.0 * Complex.Log(G1));
            }
            else
            {
                // Original Heston formulation.
                G1 = (1.0 - g1 * Complex.Exp(d1 * T)) / (1.0 - g1);
                C1 = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b1 - rho * sigma * i * phi + d1) * T - 2.0 * Complex.Log(G1));
                D1 = (b1 - rho * sigma * i * phi + d1) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d1 * T)) / (1.0 - g1 * Complex.Exp(d1 * T)));
            }
            f1 = Complex.Exp(C1 + D1 * v0 + i * phi * x);

            // The second characteristic function
            u2 = -0.5;
            b2 = kappa + lambda;
            d2 = Complex.Sqrt(Complex.Pow(rho * sigma * i * phi - b2, 2) 
                - sigma * sigma * (2.0 * u2 * i * phi - phi * phi));
            g2 = (b2 - rho * sigma * i * phi + d2) / (b2 - rho * sigma * i * phi - d2);
            if (Trap == 1)
            {
                // "Little Heston Trap" formulation
                c2 = 1.0 / g2;
                D2 = (b2 - rho * sigma * i * phi - d2) / sigma / sigma 
                    * ((1.0 - Complex.Exp(-d2 * T)) / (1.0 - c2 * Complex.Exp(-d2 * T)));
                G2 = (1.0 - c2 * Complex.Exp(-d2 * T)) / (1.0 - c2);
                C2 = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b2 - rho * sigma * i * phi - d2) * T - 2.0 * Complex.Log(G2));
            }
            else
            {
                // Original Heston formulation.
                G2 = (1.0 - g2 * Complex.Exp(d2 * T)) / (1.0 - g2);
                C2 = (r - q) * i * phi * T + a / sigma / sigma 
                    * ((b2 - rho * sigma * i * phi + d2) * T - 2.0 * Complex.Log(G2));
                D2 = (b2 - rho * sigma * i * phi + d2) / sigma / sigma 
                    * ((1.0 - Complex.Exp(d2 * T)) / (1.0 - g2 * Complex.Exp(d2 * T)));
            }
            f2 = Complex.Exp(C2 + D2 * v0 + i * phi * x);

            // The integrand.
            integrand = Complex.Exp(-i * phi * Complex.Log(K)) / i / phi 
                * (S * Complex.Exp(-q * T) * f1 - K * Complex.Exp(-r * T) * f2);

            // Return the real part of the integrand.
            return integrand.Real;
        }


        // Heston Price by Gauss-Laguerre Integration
        public double HestonPriceConsol(HParam param, OpSet settings, double[] x, double[] w)
        {
            double[] int1 = new Double[32];
            // Numerical integration
            for (int j = 0; j <= 31; j++)
            {
                int1[j] = w[j] * HestonProbConsol(x[j], param, settings);
            }

            // Define P1 and P2
            double pi = Math.PI;
            double I = int1.Sum();

            // The call price
            double S = settings.S;
            double K = settings.K;
            double r = settings.r;
            double q = settings.q;
            double T = settings.T;
            string PutCall = settings.PutCall;
            double HestonC = 0.5 * S * Math.Exp(-q * T) - 0.5 * K * Math.Exp(-r * T) + I / pi;

            // The put price by put-call parity
            double HestonP = HestonC - S * Math.Exp(-q * T) + K * Math.Exp(-r * T);

            // Output the option price
            if (PutCall == "C")
                return HestonC;
            else
                return HestonP;
        }
    }
}

