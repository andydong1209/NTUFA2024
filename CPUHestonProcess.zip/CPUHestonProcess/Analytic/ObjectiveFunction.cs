﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
using System.IO;

namespace DHestonModel
{
    public class ObjFuncAWLL
    {
        public double f(double[] param, Likelihood.OFSet ofset)
        {
            // Name the Heston parameters
            double kappa = param[0];
            double theta = param[1];
            double sigma = param[2];
            double v0 = param[3];
            double rho = param[4];

            // Likelihood function settings
            double[] x = ofset.x;
            double r = ofset.r;
            double q = ofset.q;
            double dt = ofset.dt;
            int Lmethod = ofset.method;

            // Atiya and Wall parameterization
            double alpha = kappa * theta;
            double beta = kappa;

            // Number of log-stock prices
            int T = x.Length;

            // Drift term
            double mu = r - q;

            // Equation (17)
            double betap = 1.0 - beta * dt;

            // Equation (18) - denominator of d(t)
            double D = 2.0 * Math.PI * sigma * Math.Sqrt(1.0 - rho * rho) * dt;

            // Equation (14)
            double a = (betap * betap + rho * sigma * betap * dt + sigma * sigma * dt * dt / 4.0) / (2.0 * sigma * sigma * (1.0 - rho * rho) * dt);

            // Variance and likelihood at time t = 0
            double[] v = new Double[T];
            double[] L = new Double[T];
            v[0] = v0;
            if (Lmethod == 1)
                L[0] = Math.Exp(-v[0]);    // Construct the Likelihood
            else if (Lmethod == 2)
                L[0] = -v[0];         // Construct the log-likelihood

            // Construction the likelihood for time t = 1 through t = T
            double dx, B, C, bt, x1, x2, E;
            for (int t = 0; t <= T - 2; t++)
            {
                // Stock price increment
                dx = x[t + 1] - x[t];
                // Equations (31) and (32)
                B = -alpha * dt - rho * sigma * (dx - mu * dt);
                C = alpha * alpha * dt * dt + 2.0 * rho * sigma * alpha * dt * (dx - mu * dt) + sigma * sigma * Math.Pow(dx - mu * dt, 2.0) - 2.0 * v[t] * v[t] * a * sigma * sigma * (1.0 - rho * rho) * dt;
                // Equation (30) to update the variance
                if (B * B - C > 0.0)
                    v[t + 1] = Math.Sqrt(B * B - C) - B;
                else
                {
                    // If v[t+1] is negative, use the approximation Equation (33)
                    bt = (Math.Pow(v[t] - alpha * dt, 2.0) - 2.0 * rho * sigma * (v[t] - alpha * dt) * (dx - mu * dt) + sigma * sigma * Math.Pow(dx - mu * dt, 2.0)) / (2.0 * sigma * sigma * (1.0 - rho * rho) * dt);
                    if (bt / a > 0.0)
                        v[t + 1] = Math.Sqrt(bt / a);
                    else
                        // If v[t+1] is still negative, take the previous value
                        v[t + 1] = v[t];
                }
                // Equation (15) and (16)
                bt = (Math.Pow(v[t + 1] - alpha * dt, 2.0) - 2.0 * rho * sigma * (v[t + 1] - alpha * dt) * (dx - mu * dt) + sigma * sigma * Math.Pow(dx - mu * dt, 2.0)) / (2.0 * sigma * sigma * (1.0 - rho * rho) * dt);
                x1 = ((2.0 * betap + rho * sigma * dt) * (v[t + 1] - alpha * dt) - (2.0 * rho * sigma * betap + sigma * sigma * dt) * (dx - mu * dt)) / (2.0 * sigma * sigma * (1.0 - rho * rho) * dt);
                x2 = -2.0 * Math.Sqrt(a * bt);
                // Compbined exponent for Equation (34)
                E = Math.Exp(x1 + x2) / D;
                if (Lmethod == 1)
                    // Equation (34) for the likelihood L[t+1]
                    L[t + 1] = Math.Pow(a * bt, -0.25) * E * L[t];
                else if (Lmethod == 2)
                    // Alternatively, use the log-likelihood, log of Equation (34)
                    L[t + 1] = -0.25 * Math.Log(a * bt) + x1 + x2 - Math.Log(D) + L[t];
            }
            // Negative likelihood is the last term.
            // Since we maximize the likelihood, we minimize the negative likelihood.
            return -L[T - 1];
        }
    }
    
    public class ObjFuncDiffEvo
    {
        // SVC objective function ===========================================================================
        public double f(double[] param, DiffEvoAlgo.OFSet ofset)
        {
            HestonPrice HP = new HestonPrice();
            Bisection B = new Bisection();

            double S = ofset.opset.S;
            double r = ofset.opset.r;
            double q = ofset.opset.q;
            int trap = ofset.opset.trap;

            double[,] MktIV    = ofset.data.MktIV;
            double[,] MktPrice = ofset.data.MktPrice;
            string[,] PutCall  = ofset.data.PutCall;
            double[] K = ofset.data.K;
            double[] T = ofset.data.T;
            double[] X = ofset.X;
            double[] W = ofset.W;
            string CF = ofset.CF;
            int LossFunction = ofset.LossFunction;

            int NK = PutCall.GetLength(0);
            int NT = PutCall.GetLength(1);
            int NX  = X.Length;

             HParam param2 = new HParam();
            param2.kappa = param[0];
            param2.theta = param[1];
            param2.sigma = param[2];
            param2.v0    = param[3];
            param2.rho   = param[4];

            // Settings for the Bisection algorithm
            double a = 0.001;
            double b = 3.0;
            double Tol = 1e5;
            int MaxIter = 10000;

            // Initialize the model price and model implied vol vectors, and the objective function value
            double[,] ModelPrice = new double[NK,NT];
            double[,] ModelIV    = new double[NK,NT];
            double Vega = 0.0;
            double Error = 0.0;
            double pi = Math.PI;

            if((param2.kappa<=0)  || (param2.theta<=0) || (param2.sigma<=0) || (param2.v0<=0) || (param2.rho<=-1) || 
                (param2.kappa>=20) || (param2.theta>=2) || (param2.sigma>=2) || (param2.v0>=3) || (param2.rho>=1))
                Error = 1e50;
            else
            {
                Complex phi = new Complex(0.0,0.0);
                double phi2 = 0.0;
                Complex i   = new Complex(0.0,1.0);
                Complex[] f2 = new Complex[NX];
                Complex[] f1 = new Complex[NX];
                Complex[] f  = new Complex[NX];
                double[] int1 = new double[NX];
                double[] int2 = new double[NX];
                Complex I1 = new Complex(0.0,0.0);
                Complex I2 = new Complex(0.0,0.0);
                double CallPrice = 0.0;

                for(int t=0;t<NT;t++)
                {
                    for(int j=0;j<NX;j++)
                    {
                        phi = X[j];
                        if(CF == "Heston")
                        {
                            f2[j] = HP.HestonCF(phi,param2,S,r,q,T[t],trap);
                            f1[j] = HP.HestonCF(phi-i,param2,S,r,q,T[t],trap) / (S*Math.Exp((r-q)*T[t]));
                        }
                        else if(CF == "Attari")
                            phi2 = X[j];
                        f[j] = HP.AttariCF(phi2,param2,T[t],S,r,q,trap);
                    }
                    for(int k=0;k<NK;k++)
                    {
                        double L = Math.Log(Math.Exp(-r*T[t])*K[k]/S);
                        for(int j=0;j<NX;j++)
                        {
                            phi = X[j];
                            if(CF == "Heston")
                            {
                                I1 = Complex.Exp(-i*phi*Complex.Log(K[k]))*f1[j] / i / phi;
                                int1[j] = W[j] * I1.Real;
                                I2 = Complex.Exp(-i*phi*Complex.Log(K[k]))*f2[j] / i / phi;
                                int2[j] = W[j] * I2.Real;
                            }
                            else if(CF == "Attari")
                            {
                                phi2 = X[j];
                                double fR = f[j].Real;
                                double fI = f[j].Imaginary;
                                int1[j] = W[j] * ((fR + fI/phi2)*Math.Cos(L*phi2) + (fI - fR/phi2)*Math.Sin(L*phi2)) / (1 + phi2*phi2);
                            }
                        }
                        if(CF == "Heston")
                        {
                            double P1 = 0.5 + 1.0/pi*int1.Sum();
                            double P2 = 0.5 + 1.0/pi*int2.Sum();
                            CallPrice = S*Math.Exp(-q*T[t])*P1 - K[k]*Math.Exp(-r*T[t])*P2;
                        }
                        else if(CF == "Attari")
                            CallPrice = S*Math.Exp(-q*T[t]) - K[k]*Math.Exp(-r*T[t])*(0.5 + 1.0/pi*int1.Sum());

                        if(PutCall[k,t] == "C")
                            ModelPrice[k,t] = CallPrice;
                        else
                            ModelPrice[k,t] = CallPrice - S*Math.Exp(-q*T[t]) + Math.Exp(-r*T[t])*K[k];

                        // Select the objective function
                        switch(LossFunction)
                        {
                            case 1:
                                // MSE Loss Function
                                Error += Math.Pow(ModelPrice[k,t] - MktPrice[k,t],2) / Convert.ToDouble(NT*NK); ;
                                break;
                            case 2:
                                // RMSE Loss Function
                                Error += Math.Pow(ModelPrice[k,t] - MktPrice[k,t],2) / MktPrice[k,t] / Convert.ToDouble(NT*NK); ;
                                break;
                            case 3:
                                // IVMSE Loss Function
                                ModelIV[k,t] = B.BisecBSIV(PutCall[k,t],S,K[k],r,q,T[t],a,b,ModelPrice[k,t],Tol,MaxIter);
                                Error += Math.Pow(ModelIV[k,t] - MktIV[k,t],2) / Convert.ToDouble(NT*NK); ;
                                break;
                            case 4:
                                // IVRMSE Christoffersen, Heston, Jacobs proxy
                                double d = (Math.Log(S/K[k]) + (r-q+MktIV[k,t]*MktIV[k,t]/2.0)*T[t])/MktIV[k,t]/Math.Sqrt(T[t]);
                                double NormPDF = Math.Exp(-0.5*d*d)/Math.Sqrt(2*pi);
                                Vega = S*NormPDF*Math.Sqrt(T[t]);
                                Error += Math.Pow(ModelPrice[k,t] - MktPrice[k,t],2) / Vega / Vega / Convert.ToDouble(NT*NK);
                                break;
                        }
                    }
                }
            }
            return Error;
        }
    }

    public class ObjFuncSP500
    {
        // Objective function ===========================================================================
        public double f(double[] param, SP500.OFSet ofset)
        {
            Bisection BA = new Bisection();
            HestonPrice HP = new HestonPrice();
            double S = ofset.opsettings.S;
            double r = ofset.opsettings.r;
            double q = ofset.opsettings.q;
            int trap = ofset.opsettings.trap;

            double[,] MktIV = ofset.data.MktIV;
            double[,] MktPrice = ofset.data.MktPrice;
            string[,] PutCall = ofset.data.PutCall;
            double[] K = ofset.data.K;
            double[] T = ofset.data.T;

            int NK = PutCall.GetLength(0);
            int NT = PutCall.GetLength(1);

            SP500.HParam param2 = new SP500.HParam();
            param2.kappa = param[0];
            param2.theta = param[1];
            param2.sigma = param[2];
            param2.v0 = param[3];
            param2.rho = param[4];

            // Settings for the Bisection algorithm
            double a = 0.001;
            double b = 3.0;
            double Tol = 1e5;
            int MaxIter = 10000;

            // Initialize the model price and model implied vol vectors, and the objective function value
            double[,] ModelPrice = new double[NK, NT];
            double[,] ModelIV = new double[NK, NT];
            double Vega = 0.0;
            double Error = 0.0;
            double pi = Math.PI;

            double[] lb = ofset.lb;
            double[] ub = ofset.ub;

            double kappaLB = lb[0]; double kappaUB = ub[0];
            double thetaLB = lb[1]; double thetaUB = ub[1];
            double sigmaLB = lb[2]; double sigmaUB = ub[2];
            double v0LB = lb[3]; double v0UB = ub[3];
            double rhoLB = lb[4]; double rhoUB = ub[4];

            int LossFunction = ofset.LossFunction;
            double[] X = ofset.X;
            double[] W = ofset.W;

            // Penalty for inadmissible parameter values
            if ((param2.kappa <= kappaLB) || (param2.theta <= thetaLB) || (param2.sigma <= sigmaLB) || (param2.v0 <= v0LB) || (param2.rho <= rhoLB) ||
               (param2.kappa >= kappaUB) || (param2.theta >= thetaUB) || (param2.sigma >= sigmaUB) || (param2.v0 >= v0UB) || (param2.rho >= rhoUB))
                Error = 1e50;
            else
            {
                for (int k = 0; k < NK; k++)
                {
                    for (int t = 0; t < NT; t++)
                    {
                        ModelPrice[k, t] = HP.HestonPriceGaussLaguerre(param2, S, K[k], r, q, T[t], trap, PutCall[k, t], X, W);
                        switch (LossFunction)
                        {
                            case 1:
                                // MSE Loss Function
                                Error += Math.Pow(ModelPrice[k, t] - MktPrice[k, t], 2) / Convert.ToDouble(NT * NK);
                                break;
                            case 2:
                                // RMSE Loss Function
                                Error += Math.Pow(ModelPrice[k, t] - MktPrice[k, t], 2) / MktPrice[k, t] / Convert.ToDouble(NT * NK);
                                break;
                            case 3:
                                // IVMSE Loss Function
                                ModelIV[k, t] = BA.BisecBSIV(PutCall[k, t], S, K[k], r, q, T[t], a, b, ModelPrice[k, t], Tol, MaxIter);
                                Error += Math.Pow(ModelIV[k, t] - MktIV[k, t], 2) / Convert.ToDouble(NT * NK); ;
                                break;
                            case 4:
                                // IVRMSE Christoffersen, Heston, Jacobs proxy
                                double d = (Math.Log(S / K[k]) + (r - q + MktIV[k, t] * MktIV[k, t] / 2.0) * T[t]) / MktIV[k, t] / Math.Sqrt(T[t]);
                                double NormPDF = Math.Exp(-0.5 * d * d) / Math.Sqrt(2.0 * pi);
                                Vega = S * NormPDF * Math.Sqrt(T[t]);
                                Error += Math.Pow(ModelPrice[k, t] - MktPrice[k, t], 2) / Vega / Vega / Convert.ToDouble(NT * NK);
                                break;
                        }
                    }
                }
            }
            return Error;
        }
    }

    public class ObjFuncSP500SVC
    {
        // Objective function ===========================================================================
        public double f(double[] param, SP500SVC.OFSet ofset)
        {
            HestonPrice HP = new HestonPrice();
            Bisection BA = new Bisection();

            double S = ofset.opset.S;
            double r = ofset.opset.r;
            double q = ofset.opset.q;
            int trap = ofset.opset.trap;

            double[,] MktIV = ofset.data.MktIV;
            double[,] MktPrice = ofset.data.MktPrice;
            string[,] PutCall = ofset.data.PutCall;
            double[] K = ofset.data.K;
            double[] T = ofset.data.T;
            double[] X = ofset.X;
            double[] W = ofset.W;
            string CF = ofset.CF;
            int LossFunction = ofset.LossFunction;

            int NK = PutCall.GetLength(0);
            int NT = PutCall.GetLength(1);
            int NX = X.Length;

            SP500SVC.HParam param2 = new SP500SVC.HParam();
            param2.kappa = param[0];
            param2.theta = param[1];
            param2.sigma = param[2];
            param2.v0 = param[3];
            param2.rho = param[4];

            // Settings for the Bisection algorithm
            double a = 0.001;
            double b = 3.0;
            double Tol = 1e5;
            int MaxIter = 10000;

            // Initialize the model price and model implied vol vectors, and the objective function value
            double[,] ModelPrice = new double[NK, NT];
            double[,] ModelIV = new double[NK, NT];
            double Vega = 0.0;
            double Error = 0.0;
            double pi = Math.PI;

            double[] lb = ofset.lb;
            double[] ub = ofset.ub;

            double kappaLB = lb[0]; double kappaUB = ub[0];
            double thetaLB = lb[1]; double thetaUB = ub[1];
            double sigmaLB = lb[2]; double sigmaUB = ub[2];
            double v0LB = lb[3]; double v0UB = ub[3];
            double rhoLB = lb[4]; double rhoUB = ub[4];

            if ((param2.kappa <= kappaLB) || (param2.theta <= thetaLB) || (param2.sigma <= sigmaLB) || (param2.v0 <= v0LB) || (param2.rho <= rhoLB) ||
               (param2.kappa >= kappaUB) || (param2.theta >= thetaUB) || (param2.sigma >= sigmaUB) || (param2.v0 >= v0UB) || (param2.rho >= rhoUB))
                Error = 1e50;
            else
            {
                Complex phi = new Complex(0.0, 0.0);
                double phi2 = 0.0;
                Complex i = new Complex(0.0, 1.0);
                Complex[] f2 = new Complex[NX];
                Complex[] f1 = new Complex[NX];
                Complex[] f = new Complex[NX];
                double[] int1 = new double[NX];
                double[] int2 = new double[NX];
                Complex I1 = new Complex(0.0, 0.0);
                Complex I2 = new Complex(0.0, 0.0);
                double CallPrice = 0.0;

                for (int t = 0; t < NT; t++)
                {
                    for (int j = 0; j < NX; j++)
                    {
                        phi = X[j];
                        if (CF == "Heston")
                        {
                            f2[j] = HP.HestonCF(phi, param2, S, r, q, T[t], trap);
                            f1[j] = HP.HestonCF(phi - i, param2, S, r, q, T[t], trap) / (S * Math.Exp((r - q) * T[t]));
                        }
                        else if (CF == "Attari")
                            phi2 = X[j];
                        f[j] = HP.AttariCF(phi2, param2, T[t], S, r, q, trap);
                    }
                    for (int k = 0; k < NK; k++)
                    {
                        double L = Math.Log(Math.Exp(-r * T[t]) * K[k] / S);
                        for (int j = 0; j < NX; j++)
                        {
                            phi = X[j];
                            if (CF == "Heston")
                            {
                                I1 = Complex.Exp(-i * phi * Complex.Log(K[k])) * f1[j] / i / phi;
                                int1[j] = W[j] * I1.Real;
                                I2 = Complex.Exp(-i * phi * Complex.Log(K[k])) * f2[j] / i / phi;
                                int2[j] = W[j] * I2.Real;
                            }
                            else if (CF == "Attari")
                            {
                                phi2 = X[j];
                                double fR = f[j].Real;
                                double fI = f[j].Imaginary;
                                int1[j] = W[j] * ((fR + fI / phi2) * Math.Cos(L * phi2) + (fI - fR / phi2) * Math.Sin(L * phi2)) / (1 + phi2 * phi2);
                            }
                        }
                        if (CF == "Heston")
                        {
                            double P1 = 0.5 + 1.0 / pi * int1.Sum();
                            double P2 = 0.5 + 1.0 / pi * int2.Sum();
                            CallPrice = S * Math.Exp(-q * T[t]) * P1 - K[k] * Math.Exp(-r * T[t]) * P2;
                        }
                        else if (CF == "Attari")
                            CallPrice = S * Math.Exp(-q * T[t]) - K[k] * Math.Exp(-r * T[t]) * (0.5 + 1.0 / pi * int1.Sum());

                        if (PutCall[k, t] == "C")
                            ModelPrice[k, t] = CallPrice;
                        else
                            ModelPrice[k, t] = CallPrice - S * Math.Exp(-q * T[t]) + Math.Exp(-r * T[t]) * K[k];

                        // Select the objective function
                        switch (LossFunction)
                        {
                            case 1:
                                // MSE Loss Function
                                Error += Math.Pow(ModelPrice[k, t] - MktPrice[k, t], 2) / Convert.ToDouble(NT * NK); ;
                                break;
                            case 2:
                                // RMSE Loss Function
                                Error += Math.Pow(ModelPrice[k, t] - MktPrice[k, t], 2) / MktPrice[k, t] / Convert.ToDouble(NT * NK); ;
                                break;
                            case 3:
                                // IVMSE Loss Function
                                ModelIV[k, t] = BA.BisecBSIV(PutCall[k, t], S, K[k], r, q, T[t], a, b, ModelPrice[k, t], Tol, MaxIter);
                                Error += Math.Pow(ModelIV[k, t] - MktIV[k, t], 2) / Convert.ToDouble(NT * NK); ;
                                break;
                            case 4:
                                // IVRMSE Christoffersen, Heston, Jacobs proxy
                                double d = (Math.Log(S / K[k]) + (r - q + MktIV[k, t] * MktIV[k, t] / 2.0) * T[t]) / MktIV[k, t] / Math.Sqrt(T[t]);
                                double NormPDF = Math.Exp(-0.5 * d * d) / Math.Sqrt(2 * pi);
                                Vega = S * NormPDF * Math.Sqrt(T[t]);
                                Error += Math.Pow(ModelPrice[k, t] - MktPrice[k, t], 2) / Vega / Vega / Convert.ToDouble(NT * NK);
                                break;
                        }
                    }
                }
            }
            return Error;
        }
    }

    public class ObjFuncGauthier
    {
        // Returns the objective function for calculating the Gauthier and Rivaille coefficients under optimization
        public double f(double[] param, double[] Coeff1, double[] Coeff2, double Put1, double Put2)
        {
            double sigma = param[0];
            double rho = param[1];

            double A1 = Coeff1[0];
            double B1 = Coeff1[1];
            double C1 = Coeff1[2];
            double D1 = Coeff1[3];

            double A2 = Coeff2[0];
            double B2 = Coeff2[1];
            double C2 = Coeff2[2];
            double D2 = Coeff2[3];

            double ObjFun = Math.Pow(A1 + B1 * sigma * sigma + C1 * rho * sigma + D1 * rho * rho * sigma * sigma - Put1, 2) +
                            Math.Pow(A2 + B2 * sigma * sigma + C2 * rho * sigma + D2 * rho * rho * sigma * sigma - Put2, 2);
            return ObjFun;
        }
    }

}
 
