﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;
using DHestonModel;

namespace Analytic
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpSet opSet = new OpSet();
            HParam hParam = new HParam();

            opSet.PutCall = "C";
            opSet.S = Convert.ToDouble(textBox2.Text);
            opSet.K = Convert.ToDouble(textBox3.Text);
            opSet.T = Convert.ToDouble(textBox4.Text);
            opSet.r = Convert.ToDouble(textBox5.Text);
            opSet.q = Convert.ToDouble(textBox6.Text);            

            hParam.kappa = Convert.ToDouble(textBox7.Text);
            hParam.theta = Convert.ToDouble(textBox8.Text);
            hParam.sigma = Convert.ToDouble(textBox9.Text);
            hParam.v0 = Convert.ToDouble(textBox10.Text);
            hParam.rho = Convert.ToDouble(textBox11.Text);
            hParam.lambda = Convert.ToDouble(textBox12.Text);

            Stopwatch SW = new Stopwatch();
            SW.Start();
            //T01_GaussLaguerre.GaussLaguerre();
            double C0 = T01_GaussLaguerre.GaussLaguerreConsolidated(opSet, hParam);
            textBox13.Text = C0.ToString();
            SW.Stop();
            textBox21.Text = SW.ElapsedMilliseconds.ToString();

            double dS = 0.005 * opSet.S;
            opSet.S = opSet.S + dS;
            double Cplus = T01_GaussLaguerre.GaussLaguerreConsolidated(opSet, hParam);
            opSet.S = opSet.S - dS;
            double Cminus = T01_GaussLaguerre.GaussLaguerreConsolidated(opSet, hParam);
            double CDelta = (Cplus - Cminus) / (2 * dS);
            textBox15.Text = CDelta.ToString();

            opSet.PutCall = "P";
            double P0 = T01_GaussLaguerre.GaussLaguerreConsolidated(opSet, hParam);
            textBox14.Text = P0.ToString();

            opSet.S = opSet.S + dS;
            double Pplus = T01_GaussLaguerre.GaussLaguerreConsolidated(opSet, hParam);
            opSet.S = opSet.S - dS;
            double Pminus = T01_GaussLaguerre.GaussLaguerreConsolidated(opSet, hParam);
            double PDelta = (Pplus - Pminus) / (2 * dS);
            textBox16.Text = PDelta.ToString();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            /*
            settings.S = 101.52;
            settings.K = 100.0;
            settings.T = 0.25;
            settings.r = 0.02;
            settings.q = 0.0;
            */

            textBox1.Text = "P";                        // "P"ut or "C"all
            textBox2.Text = Convert.ToString(101.52);   // Spot Price
            textBox3.Text = Convert.ToString(100.0);    // Strike Price
            textBox4.Text = Convert.ToString(0.25);	    // Maturity in Years
            textBox5.Text = Convert.ToString(0.02);	    // Interest Rate
            textBox6.Text = Convert.ToString(0.0);      // Dividend yield            

            /*
            param.kappa = 1.5;
            param.theta = 0.04;
            param.sigma = 0.3;
            param.v0 = 0.05412;
            param.rho = -0.9;
            param.lambda = 0.0;
            */

            textBox7.Text = Convert.ToString(1.5);		// Heston Parameter: Mean reversion speed
            textBox8.Text = Convert.ToString(0.04);	    // Heston Parameter: Mean reversion level 
            textBox9.Text = Convert.ToString(0.3);	    // Heston Parameter: Volatility of Variance
            textBox10.Text = Convert.ToString(0.05412);	// Heston Parameter: Current Variance
            textBox11.Text = Convert.ToString(-0.9);	// Heston Parameter: Correlation
            textBox12.Text = Convert.ToString(0.0);	    // Heston Parameter: Risk parameter 
        }
    }
}
