﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;
using DFinMath;

namespace STHestonProcess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public struct BlackRec
        {
            public double Spot;
            public double Strike;
            public double TTM;
            public double Cost;
            public double Yield;
        }

        public struct HestonRec
        {
            public double Variance;
            public double Kappa;
            public double Theta;
            public double Sigma;
            public double Rho;
        }

        public BlackRec Black;
        public HestonRec Heston;

        const int cnBlocks = 256; // Block size
        const int cnBlockSize = 256; // Thread size
        const int NPath = cnBlocks * cnBlockSize;

        static int MStep;
        static DateTime RefDate;
        static List<DateTime> FixingDate;
        static int[] h_StepGrid;

        public double MPrice;
        public double MDelta;
        public double MGamma;
        public double MTheta;

        private void button2_Click(object sender, EventArgs e)
        {
            Black = new BlackRec();
            {
                Black.Spot = 103.44;
                Black.Strike = 100.0;
                Black.TTM = 1.0;
                Black.Cost = 0.001521;
                Black.Yield = 0.003444;
            }

            Heston = new HestonRec();
            {
                Heston.Variance = 0.00770547621786487;
                Heston.Kappa = 2.20366282736578;
                Heston.Theta = 0.0164951784035976;
                Heston.Sigma = 0.33220849746904;
                Heston.Rho = -0.277814270110106;
            }

            //MersenneTwister Rnd = new MersenneTwister(1234);//6.3235755357986
            //MersenneTwister Rnd = new MersenneTwister(4321);//6.24623103037676
            Random Rnd = new Random(1234);//6.21205916009444
            Stopwatch SW = new Stopwatch();

            RefDate = new DateTime(2014, 7, 1);
            FixingDate = new List<DateTime>();

            //MStep depend on the remaining FixingDay Number, Including RefDate
            MStep = 13; // 0, 1, 2,..., 12, 0 for RefDate
            for (int i = 0; i < MStep; i++)
            {
                FixingDate.Add(RefDate.AddMonths(i));
            }

            h_StepGrid = new int[MStep];
            for (int i = 0; i < MStep; i++)
            {
                TimeSpan TS = FixingDate[i].Subtract(RefDate);
                h_StepGrid[i] = (int)TS.TotalDays;
            }

            int Step = h_StepGrid[MStep - 1];
            double[] Value = new double[NPath];
            double[,] St = new double[NPath, Step + 1];

            double S = Black.Spot;
            double K = Black.Strike;
            double ttm = Black.TTM;
            double r = Black.Cost;
            double y = Black.Yield;

            SW.Start();
            for (int i = 0; i < NPath; i++)
            {
                double Var = Heston.Variance;
                double Kappa = Heston.Kappa;
                double Theta = Heston.Theta;
                double Sigma = Heston.Sigma;
                double Rho = Heston.Rho;

                double dt = (double)1.0 / (double)365.0;
                double Sqrtdt = Math.Sqrt(dt);
                double Sqrt1_Rho2 = Math.Sqrt(1 - Rho * Rho);
                double rnd_num, rnd_num1;
                double N1, N2;

                double vol;  //= sqrt(fabs(Var));
                double vol2; //= Sigma * vol;
                double mu;   //= r-y-0.5*vol*vol;
                double nu;   //= Kappa *(Theta-vol*vol);

                S = Black.Spot;
                St[i, 0] = S;

                for (int j = 0; j < (MStep - 1); j++)
                {
                    for (int k = h_StepGrid[j]; k < h_StepGrid[j + 1]; k++)
                    {
                        rnd_num = DStat.N_Inv(Rnd.NextDouble());
                        rnd_num1 = DStat.N_Inv(Rnd.NextDouble());

                        // Correlated N1, N2
                        N1 = rnd_num;
                        N2 = Rho * rnd_num + Sqrt1_Rho2 * rnd_num1;

                        vol = Math.Sqrt(Math.Abs(Var));
                        //if (Var < 0.0) Var = 0.0;
                        //vol = Math.Sqrt(Var);
                        vol2 = Sigma * vol;
                        mu = r - y - 0.5 * vol * vol;
                        nu = Kappa * (Theta - vol * vol);

                        S = S * Math.Exp(mu * dt + vol * N1 * Sqrtdt);
                        Var = vol * vol + nu * dt + vol2 * Sqrtdt * N2;
                        St[i, k + 1] = S;
                    }
                }
                double dif_call = S - K;
                Value[i] = Math.Max(dif_call, 0.0);
            }

            double VCall = 0.0;
            for (int i = 0; i < NPath; i++)
            {
                VCall = VCall + Value[i];
            }
            VCall = (VCall / NPath) * Math.Exp(-r * ttm);
            SW.Stop();

            double AnalyticNPV = 6.21877418675479;
            double gap = VCall - AnalyticNPV;
            double ratio = gap / AnalyticNPV * 100.0;
            textBox1.Text = SW.ElapsedMilliseconds.ToString();
            textBox2.Text = AnalyticNPV.ToString();
            textBox3.Text = VCall.ToString();
            textBox4.Text = gap.ToString();
            textBox5.Text = ratio.ToString();

            for (int i = 0; i <= 365; i++)
            {
                listBox1.Items.Add(St[0, i].ToString());
            }

            for (int i = 0; i <= 365; i++)
            {
                listBox2.Items.Add(St[1, i].ToString());
            }

            for (int i = 0; i <= 20; i++)
            {
                listBox3.Items.Add(Value[i].ToString());
            }
        }
    }
}
