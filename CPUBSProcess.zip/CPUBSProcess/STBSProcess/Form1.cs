﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

using System.Diagnostics;
using DFinMath;

namespace STBSProcess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        const int BlocksPerGrid = 256;
        const int ThreadsPerBlock = 512;
        static int NPath = ThreadsPerBlock * BlocksPerGrid; //131,072 Paths
        static int MStep = 13;

        static DateTime RefDate;
        static List<DateTime> FixingDate;
        static int[] h_StepGrid;

        double[,] S = new double[NPath, MStep];
        double[] Value = new double[NPath];

        private void button3_Click(object sender, EventArgs e)
        {
            double Asset = 100.0;
            double Strike = 100.0;
            double TTM = 1.0;
            double Sigma = 0.3;
            double Rate = 0.04;
            double Yield = 0.02;
            double dt = 1.0 / 365.0;

            // Analytic Benchmark
            double d1 = (Math.Log(Asset / Strike)
                + (Rate - Yield + 0.5 * Sigma * Sigma) * TTM)
                / (Sigma * Math.Sqrt(TTM));
            double d2 = d1 - Sigma * Math.Sqrt(TTM);

            double CValue = Asset * Math.Exp(-Yield * TTM) * DStat.NormDist(d1)
                - Strike * Math.Exp(-Rate * TTM) * DStat.NormDist(d2);

            double PValue = Strike * Math.Exp(-Rate * TTM) * DStat.NormDist(-d2)
                - Asset * Math.Exp(-Yield * TTM) * DStat.NormDist(-d1);


            //Random Rnd = new Random(1234);
            MersenneTwister Rnd = new MersenneTwister(1234);
            Stopwatch SW = new Stopwatch();

            RefDate = new DateTime(2014, 7, 1);
            FixingDate = new List<DateTime>();

            //MStep depend on the remaining FixingDay Number, Including RefDate
            // 0, 1, 2,..., 12, 0 for RefDate
            for (int i = 0; i < MStep; i++)
            {
                FixingDate.Add(RefDate.AddMonths(i));
            }

            h_StepGrid = new int[MStep];
            for (int i = 0; i < MStep; i++)
            {
                TimeSpan TS = FixingDate[i].Subtract(RefDate);
                h_StepGrid[i] = (int)TS.TotalDays;
            }

            double s1, n1;

            SW.Start();
            for (int i = 0; i < NPath; i++)
            {
                s1 = Asset;
                int diff = 0;
                S[i, 0] = s1;
                for (int j = 0; j < (MStep - 1); j++)
                {
                    diff = h_StepGrid[j + 1] - h_StepGrid[j];
                    for (int k = 0; k < diff; k++)
                    {
                        n1 = DStat.N_Inv(Rnd.NextDouble());
                        s1 = s1 * Math.Exp(((Rate - Yield) - (Sigma * Sigma) / 2.0) * dt
                            + (Sigma * Math.Sqrt(dt) * n1));
                    }
                    S[i, j + 1] = s1;
                }
                Value[i] = Math.Max(s1 - Strike, 0);
            }

            double sum = 0.0;
            for (int i = 0; i < NPath; i++)
            {
                sum = sum + Value[i];
            }
            sum = (sum / NPath) * Math.Exp(-Rate * TTM);
            SW.Stop();

            double gap = sum - CValue;
            double ratio = (gap / CValue) * 100.0;

            textBox1.Text = SW.ElapsedMilliseconds.ToString();
            textBox2.Text = CValue.ToString();
            textBox3.Text = sum.ToString();
            textBox4.Text = gap.ToString();
            textBox5.Text = ratio.ToString();

            listBox1.Items.Clear();
            for (int j = 0; j < MStep; j++)
            {
                listBox1.Items.Add(S[0, j].ToString());
            }
        }

        // Data arrays.
        string[] seriesArray = { "Path1", "Path2", "Path3", "Path4", "Path5",
                "Path6", "Path7", "Path8", "Path9", "Path10" };
        double[] pointsArray1 = new double[10];
        double[] pointsArray2 = new double[10];
        double[] pointsArray3 = new double[10];
        double[] pointsArray4 = new double[10];
        double[] pointsArray5 = new double[10];
        double[] pointsArray6 = new double[10];
        double[] pointsArray7 = new double[10];
        double[] pointsArray8 = new double[10];
        double[] pointsArray9 = new double[10];
        double[] pointsArray10 = new double[10];
        double[] pointsArray11 = new double[10];
        double[] pointsArray12 = new double[10];
        double[] pointsArray13 = new double[10];

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i= 0; i<10; i++)
            {
                pointsArray1[i] = S[i, 0];
                pointsArray2[i] = S[i, 1];
                pointsArray3[i] = S[i, 2];
                pointsArray4[i] = S[i, 3];
                pointsArray5[i] = S[i, 4];
                pointsArray6[i] = S[i, 5];
                pointsArray7[i] = S[i, 6];
                pointsArray8[i] = S[i, 7];
                pointsArray9[i] = S[i, 8];
                pointsArray10[i] = S[i, 9];
                pointsArray11[i] = S[i, 10];
                pointsArray12[i] = S[i, 11];
                pointsArray13[i] = S[i, 12];
            }

            // Set palette.
            //this.chart1.Palette = ChartColorPalette.SeaGreen;

            // Set title.
            this.chart1.Titles.Clear();
            this.chart1.Titles.Add("Simulation Path");

            // Add series.
            Series series = new Series();
            this.chart1.Series.Clear();
            for (int i = 0; i < seriesArray.Length; i++)
            {
                // Add series.
                series = this.chart1.Series.Add(seriesArray[i]);
                series.ChartType = SeriesChartType.Line;

                // Add point.
                series.Points.Add(pointsArray1[i]);
                series.Points.Add(pointsArray2[i]);
                series.Points.Add(pointsArray3[i]);
                series.Points.Add(pointsArray4[i]);
                series.Points.Add(pointsArray5[i]);
                series.Points.Add(pointsArray6[i]);
                series.Points.Add(pointsArray7[i]);
                series.Points.Add(pointsArray8[i]);
                series.Points.Add(pointsArray9[i]);
                series.Points.Add(pointsArray10[i]);
                series.Points.Add(pointsArray11[i]);
                series.Points.Add(pointsArray12[i]);
                series.Points.Add(pointsArray13[i]);
            }
        }
    }
}
