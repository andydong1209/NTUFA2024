﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;
using DFinMath;

namespace STBSBiAssetProcess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        const int BlocksPerGrid = 256;
        const int ThreadsPerBlock = 256;

        static int NPath;
        static int MStep;
        static DateTime RefDate;
        static List<DateTime> FixingDate;
        static int[] h_StepGrid;

        private void button2_Click(object sender, EventArgs e)
        {
            double Asset1 = 100.0;
            double Asset2 = 100.0;
            double Strike = 1.0;
            double TTM = 1.0;
            double Sigma = 0.3;
            double Rate = 0.04;
            double Yield = 0.02;
            double dt = 1.0 / 365.0;
            double Rho = 0.5;
            double Sqrt1mRho2 = Math.Sqrt(1 - Rho * Rho);

            //Random Rnd = new Random(1234);
            MersenneTwister Rnd = new MersenneTwister(1234);
            Stopwatch SW = new Stopwatch();

            NPath = ThreadsPerBlock * BlocksPerGrid;
            RefDate = new DateTime(2014, 7, 1);
            FixingDate = new List<DateTime>();

            //MStep depend on the remaining FixingDay Number, Including RefDate
            MStep = 13; // 0, 1, 2,..., 12, 0 for RefDate
            for (int i = 0; i < MStep; i++)
            {
                FixingDate.Add(RefDate.AddMonths(i));
            }

            h_StepGrid = new int[MStep];
            for (int i = 0; i < MStep; i++)
            {
                TimeSpan TS = FixingDate[i].Subtract(RefDate);
                h_StepGrid[i] = (int)TS.TotalDays;
            }

            double[,] S1 = new double[NPath, MStep];
            double[,] S2 = new double[NPath, MStep];
            double[] Value = new double[NPath];
            double s1, s2, n1, n2, e1, e2;

            SW.Start();
            for (int i = 0; i < NPath; i++)
            {
                s1 = Asset1;
                s2 = Asset2;
                int diff = 0;
                S1[i, 0] = s1;
                S2[i, 0] = s2;
                for (int j = 0; j < (MStep - 1); j++)
                {
                    diff = h_StepGrid[j + 1] - h_StepGrid[j];
                    for (int k = 0; k < diff; k++)
                    {
                        e1 = DStat.N_Inv(Rnd.NextDouble());
                        e2 = DStat.N_Inv(Rnd.NextDouble());

                        n1 = e1;
                        n2 = Rho * e1 + Sqrt1mRho2 * e2;

                        s1 = s1 * Math.Exp(((Rate - Yield) - (Sigma * Sigma) / 2.0) * dt
                            + (Sigma * Math.Sqrt(dt) * n1));
                        s2 = s2 * Math.Exp(((Rate - Yield) - (Sigma * Sigma) / 2.0) * dt
                            + (Sigma * Math.Sqrt(dt) * n2));
                    }
                    S1[i, j + 1] = s1;
                    S2[i, j + 1] = s2;
                }
                Value[i] = Math.Max((s1 - s2) - Strike, 0);
            }

            double sum = 0.0;
            for (int i = 0; i < NPath; i++)
            {
                sum = sum + Value[i];
            }
            sum = (sum / NPath) * Math.Exp(-Rate * TTM);
            SW.Stop();

            textBox1.Text = SW.ElapsedMilliseconds.ToString();
            textBox2.Text = sum.ToString();

            for (int j = 0; j < MStep; j++)
            {
                listBox1.Items.Add(S1[0, j].ToString());
                listBox2.Items.Add(S2[0, j].ToString());
            }
        }
    }
}
