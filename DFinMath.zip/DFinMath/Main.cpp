#include "DStat.h"
#include "DMT.h"

#include <vector>
#include <iostream>
#include <boost/timer.hpp>

using namespace DFinMath;
using namespace boost;
using namespace std;

void BSMCPricing()
{
	std::cout << " BS Model Monte-Carlo Calibration..." << endl;
	cout << " ================================================ " << endl;

	const double s0 = 100;
	const double r = 0.05;
	const double q = 0.02;
	const double vol = 0.3;

	double S = s0;
	double K = s0;
	double ttm = 1.0;
	double y = q;

	int const NPath = 100000;
	int const MStep = 365;

	vector<double> St;
	vector<double> CValue;
	vector<double> PValue;

	DStat aStat;
	DMT aMT(1234);

	std::cout << "\n ---MC Vanilla Pricing Simulation Begin ---" << endl;
	std::cout << " #Paths: " << NPath << ", #Steps: " << MStep << "." << endl;
	timer t3;

	for (int i = 0; i < NPath; i++)
	{
		double dt = ttm / 365.0;
		double Sqrtdt = sqrt(dt);
		double normal_rnd;

		S = s0;

		for (int j = 0; j < MStep; j++)
		{
			double t0 = j * dt;
			normal_rnd = aStat.N_Inv(aMT.nextReal());

			const double sig = vol;
			const double mu = r - q - 0.5*sig*sig;
			S = S * std::exp(mu*dt + sig*Sqrtdt*normal_rnd);
		}

		St.push_back(S);
		CValue.push_back(fmax(S - K, 0.0));
		PValue.push_back(fmax(K - S, 0.0));
	}

	double sum = 0.0;
	for (int i = 0; i < NPath; i++)
	{
		sum = sum + CValue[i];
	}
	double Call_Value = sum / NPath * exp(-r * ttm);
	std::cout << "\n Call Value: " << Call_Value << endl;

	cout << "\n Time elapsed now: " << t3.elapsed() << " sec." << endl;
	cout << "------------------------------------------------------" << endl;
}


int main()
{
	BSMCPricing();

	return 0;
}


/*
int main()
{
	DStat aStat;

	double x = 0.0;
	double y = aStat.NormDist(x);
	double z = aStat.N_Inv(y);

	cout << "x = " << x << ", y = " << y << endl;
	cout << "y = " << y << ", x = " << z << endl;

	int j;
	unsigned long l;

	// you can seed with any uint32, but the best are odds in 0..(2^32 - 1)
	DMT aMT(4357U);

	// Run this 40 million times
	for (j = 20; j>0; --j) 
	{
		l = aMT.randomMT();
		cout << l << endl;
	}

	cout << endl;
	for (j = 20; j>0; --j)
	{
		x = aMT.nextReal();
		cout << x << endl;
	}

	//system("pause");
}
*/

